// Copyright 2017 Istio Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package comb

import (
	"fmt"
	"strconv"
	"strings"
	"path"

	"github.com/go-chassis/go-chassis/core/registry"
	"github.com/mohae/deepcopy"
	"istio.io/istio/pilot/pkg/model"
	"istio.io/istio/pilot/pkg/serviceregistry"
	"istio.io/istio/pkg/config/host"
	"istio.io/istio/pkg/config/protocol"
	"istio.io/pkg/log"
)

const (
	protocolTagName = "protocol"
	externalTagName = "external"
)


func convertPort(endpointsMap registry.EndpointsMap) []model.Port {
	ports := []model.Port{}
	for p, endpoint := range endpointsMap{
		name := p
		port, err := strconv.Atoi( endpoint.Address[strings.Index(endpoint.Address, ":"):])
		if err != nil {
			port = 0
		}
		ports := append(ports, &model.Port{
			Name:     name,
			Port:     strconv.Atoi(portStr),
			Protocol: convertProtocol(name),
		})
	}
	return ports
}


func convertService(service *registry.MicroService, instances []*registry.MicroServiceInstance) *model.Service {
	name := service.ServiceName

	meshExternal := false
	resolution := model.ClientSideLB
	ports := make(map[int]*model.Port)
	for _, instance := range instances {
		ps := convertPort(instance.EndpointsMap)
		for port := range ports{
			if svcPort, exists := ports[port.Port]; exists && svcPort.Protocol != port.Protocol {
				log.Warnf("Service %v has two instances on same port %v but different protocols (%v, %v)",name, port.Port, svcPort.Protocol, port.Protocol)
			} else {
				ports[port.Port] = port
			}	
		}
	}

	svcPorts := make(model.PortList, 0, len(ports))
	for _, port := range ports {
		svcPorts = append(svcPorts, port)
	}

	hostname := serviceHostname(service)
	out := &model.Service{
		Hostname:     hostname,
		Address:      "0.0.0.0",
		Ports:        svcPorts,
		MeshExternal: meshExternal,
		Resolution:   resolution,
		Attributes: model.ServiceAttributes{
			ServiceRegistry: string(serviceregistry.ServiceComb),
			Name:            string(hostname),
			Namespace:       service.AppID,
		},
	}

	return out
}

func convertInstance(service *model.Service, instance *registry.MicroServiceInstance) []*model.ServiceInstance {	
	meshExternal := false
	resolution := model.ClientSideLB
	externalName := instance.Metadata[externalTagName]
	if externalName != "" {
		meshExternal = true
		resolution = model.DNSLB
	}
	svcLabels := deepcopy.Copy(instance.Metadata)
	tlsMode := model.GetTLSModeFromEndpointLabels(svcLabels)
	localityLabel = path.Join(instance.DataCenterInfo.Name,instance.DataCenterInfo.AvailableZone, instance.DataCenterInfo.Region)

	instances := []*model.ServiceInstance{}
	ports := convertPort(instance.EndpointsMap)
	for port := range ports {
		addr = instance.EndpointsMap[port.name].Address
		instances = append(instances, &model.ServiceInstance{
			Endpoint: &model.IstioEndpoint{
				Address:         addr,
				EndpointPort:    uint32(port.Port),
				ServicePortName: port.Name,
				Locality: model.Locality{
					Label: localityLabel,
				},
				Labels:  svcLabels,
				TLSMode: tlsMode,
			},
			ServicePort: &port,
			Service:     service,
		})
	}
	return instances
}

// serviceHostname produces FQDN for a consul service
func serviceHostname(service *registry.MicroService) host.Name {
	// TODO include datacenter in Hostname?
	// consul DNS uses "redis.service.us-east-1.consul" -> "[<optional_tag>].<svc>.service.[<optional_datacenter>].consul"
	return host.Name(fmt.Sprintf("%s.%s.comb", service.ServiceName, service.AppID))
}

// parseHostname extracts service name from the service hostname
func parseHostname(hostname host.Name) (name string, err error) {
	parts := string(hostname)
	parts := parts[:strings.Index(".comb")]
	)
	if len(parts) < 1  {
		err = fmt.Errorf("missing service name from the service hostname %q", hostname)
		return
	}
	name = parts[0]
	return
}

func convertProtocol(name string) protocol.Instance {
	p := protocol.Parse(name)
	if p == protocol.Unsupported {
		log.Warnf("unsupported protocol value: %s", name)
		return protocol.TCP
	}
	return p
}
